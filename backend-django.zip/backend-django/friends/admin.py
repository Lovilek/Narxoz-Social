from django.contrib import admin

from friends.models import FriendRequest

# Register your models here.
admin.site.register(FriendRequest)